# BigMarketHub — Backend (Laravel 11)

یہ فولڈر صرف ایپلیکیشن لیئر کی فائلیں رکھتا ہے (controllers, models, migrations, routes, config)۔
چونکہ اس ماحول میں Composer/Packagist تک انٹرنیٹ رسائی نہیں ہے، اس لیے مکمل Laravel skeleton
(vendor, public/index.php وغیرہ) یہاں شامل نہیں۔ اپنے کمپیوٹر پر درج ذیل اسٹیپس فالو کریں:

## سیٹ اپ اسٹیپس

1. نیا Laravel پروجیکٹ بنائیں:
   ```bash
   composer create-project laravel/laravel backend "11.*"
   cd backend
   composer require laravel/sanctum
   ```

2. اس فولڈر (`backend/`) کی درج ذیل فائلیں/فولڈرز کاپی کر کے نئے پروجیکٹ میں اسی جگہ اوورائٹ (overwrite) کر دیں:
   - `app/Models/Admin.php`, `app/Models/User.php`
   - `app/Http/Controllers/...` (سب)
   - `database/migrations/...` (سب)
   - `database/seeders/...` (سب)
   - `routes/api.php`
   - `config/auth.php`, `config/cors.php`
   - `bootstrap/app.php`
   - `.env.example` (اپنی .env میں DB معلومات سیٹ کریں)

3. `.env` بنائیں اور MySQL کی تفصیلات دیں:
   ```
   DB_DATABASE=bigmarkethub
   DB_USERNAME=root
   DB_PASSWORD=
   ```

4. Sanctum پبلش کریں (اگر ضرورت ہو):
   ```bash
   php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
   ```

5. مائیگریشن اور سیڈر چلائیں:
   ```bash
   php artisan key:generate
   php artisan migrate
   php artisan db:seed
   ```

6. سرور اسٹارٹ کریں:
   ```bash
   php artisan serve
   ```
   ڈیفالٹ: http://localhost:8000

## ڈیفالٹ ایڈمن لاگ اِن (Seeder سے)
- Email: `admin@bigmarkethub.com`
- Password: `Admin@123`

## API Endpoints

### Admin
- `POST /api/admin/login`
- `GET  /api/admin/me`            (auth:admin)
- `POST /api/admin/logout`        (auth:admin)
- `GET  /api/admin/dashboard`     (auth:admin)

### User
- `POST /api/user/register`
- `POST /api/user/login`
- `GET  /api/user/me`             (auth:user)
- `POST /api/user/logout`         (auth:user)
- `GET  /api/user/dashboard`      (auth:user)

> نوٹ: Authenticated request میں header بھیجیں: `Authorization: Bearer {token}`
