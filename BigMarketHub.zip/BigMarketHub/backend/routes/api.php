<?php

use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Auth\AdminAuthController;
use App\Http\Controllers\Auth\UserAuthController;
use App\Http\Controllers\User\DashboardController as UserDashboardController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| BigMarketHub API Routes
|--------------------------------------------------------------------------
*/

// ===================== ADMIN ROUTES =====================
Route::prefix('admin')->group(function () {
    Route::post('/login', [AdminAuthController::class, 'login']);

    Route::middleware('auth:admin')->group(function () {
        Route::post('/logout', [AdminAuthController::class, 'logout']);
        Route::get('/me', [AdminAuthController::class, 'me']);
        Route::get('/dashboard', [AdminDashboardController::class, 'index']);
    });
});

// ===================== USER ROUTES =====================
Route::prefix('user')->group(function () {
    Route::post('/register', [UserAuthController::class, 'register']);
    Route::post('/login', [UserAuthController::class, 'login']);

    Route::middleware('auth:user')->group(function () {
        Route::post('/logout', [UserAuthController::class, 'logout']);
        Route::get('/me', [UserAuthController::class, 'me']);
        Route::get('/dashboard', [UserDashboardController::class, 'index']);
    });
});
