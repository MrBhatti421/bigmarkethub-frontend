<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        return response()->json([
            'message' => 'خوش آمدید، ایڈمن ڈیش بورڈ',
            'admin' => $request->user('admin'),
            'stats' => [
                'total_users' => 0,
                'total_tasks' => 0,
                'total_projects' => 0,
            ],
        ]);
    }
}
