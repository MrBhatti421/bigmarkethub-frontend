<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        return response()->json([
            'message' => 'خوش آمدید، یوزر ڈیش بورڈ',
            'user' => $request->user('user'),
            'stats' => [
                'my_tasks' => 0,
                'completed_tasks' => 0,
                'pending_tasks' => 0,
            ],
        ]);
    }
}
