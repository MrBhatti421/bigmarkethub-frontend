# BigMarketHub — پروفیشنل ٹاسک مینجمنٹ پلیٹ فارم

## ٹیک اسٹیک
- **Frontend:** Next.js (App Router) + Tailwind CSS (Orange & Black Theme)
- **Backend:** Laravel 11 (REST API) + Sanctum
- **Database:** MySQL
- **Auth:** الگ الگ Admin اور User گارڈز (Sanctum token based)

## پروجیکٹ اسٹرکچر

```
BigMarketHub/
├── backend/     → Laravel API (auth, admin panel, user panel)
└── frontend/    → Next.js app (admin panel UI, user panel UI)
```

## اسٹیٹس: بنیادی ڈھانچہ (Phase 1) ✅

اس ورژن میں شامل ہے:
- ✅ پروجیکٹ اسٹرکچر (frontend + backend الگ الگ)
- ✅ MySQL ڈیٹابیس کنکشن سیٹ اپ
- ✅ بیسک آتھنٹیکیشن (Sanctum, الگ admin/user guards)
- ✅ ایڈمن لاگ اِن (API + UI)
- ✅ یوزر لاگ اِن + رجسٹریشن (API + UI)
- ✅ الگ الگ محفوظ (protected) ڈیش بورڈز

## سیٹ اپ ترتیب

1. پہلے `backend/README.md` کے مطابق Laravel بیک اینڈ سیٹ اپ کریں
2. پھر `frontend/README.md` کے مطابق Next.js فرنٹ اینڈ سیٹ اپ کریں
3. دونوں سرورز چلائیں (backend: 8000, frontend: 3000)
4. `http://localhost:3000` پر جا کر ٹیسٹ کریں

## اگلے مراحل (آپ کے پرامپٹس کے مطابق)
1. ✅ ~~بنیادی ڈھانچہ~~ (یہ فیز)
2. ⏳ یوزر مینجمنٹ (رولز، پرمیشنز، پروفائل)
3. ⏳ ٹاسک مینجمنٹ (پروجیکٹس، ٹاسکس، اسٹیٹس)
4. ⏳ والٹ (بیلنس، ٹرانزیکشنز)
5. ⏳ پیمنٹ سسٹم
